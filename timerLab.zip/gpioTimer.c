/*******************************************************************************
  * File Name          : gpioTimer.c
  * Description        : Controlling GPIOA pins
  *			 Control one pin to high for certain time. 
  * 
  * Author:              Group 1
  *			 Sinan KARACA
  *			 Mohammed Al Bunde
  * Date:                12.10.2021				 
  ******************************************************************************
  */
#include <stdio.h>
#include <stdint.h>
#include <ctype.h>
#include <string.h>

#include "common.h"
#include "main.h"


// Value for interrupt count
uint32_t interruptValue = 0;


TIM_HandleTypeDef tim111;



// FUNCTION      : timerInit
// DESCRIPTION   : Timer initialisation
// PARAMETERS    : void 
// RETURNS       : void

void timerInit(void){

  // Initialise the timer 
  __HAL_RCC_TIM11_CLK_ENABLE();
  tim111.Instance = TIM11;
  tim111.Init.Prescaler  =   HAL_RCC_GetPCLK2Freq() / 10000 - 1;
  tim111.Init.CounterMode = TIM_COUNTERMODE_UP;
  tim111.Init.Period        = 0xffff;
  tim111.Init.ClockDivision =
      TIM_CLOCKDIVISION_DIV1;
  tim111.Init.RepetitionCounter = 0;
  
  HAL_TIM_Base_Init(&tim111);  
  
  // Timer interrupt parameters
  HAL_NVIC_SetPriority(TIM1_TRG_COM_TIM11_IRQn, 10, 0U);
  HAL_NVIC_EnableIRQ(TIM1_TRG_COM_TIM11_IRQn);
  // Start Timer in Interrupt mode
  HAL_TIM_Base_Start_IT(&tim111);
}



// FUNCTION      : tim
// DESCRIPTION   : Connection between terminal and STM32
//       Calls the function for timer GPIO
// PARAMETERS    : int action 
// RETURNS       : CmdReturnOk / CmdReturnBadParameter1


ParserReturnVal_t tim(int mode)
{

  timerInit();
  
  
  uint32_t led,delay;
  uint32_t delayTemp = 0;
  uint32_t delayTemp1 = 0;

  int rc;
  int shiftNumber;
  
  if(mode != CMD_INTERACTIVE) return CmdReturnOk;



  // First input for pin index <1-16>
  rc = fetch_uint32_arg(&led);
  
  
  if(rc || led < 0 || led > 16 || led == 2|| led == 3) {
  
    //Check if user entered and input
    //Check if GPIOA <index> is inside 0 to 16
    //Check if <index> is 2 or 3 (Checking for uart pins)
    
    printf("Choose Pin Between 1-15\n");
    printf("Pin 2 and Pin 3 are reserved for UART\n");
    printf("Please choose other pins!\n");
    return CmdReturnBadParameter1;
    
  
  } else if(led == 16) {
    
    //If it is 16 reset all the pins to low
    
    printf("All pins are being reseted.\n");
    // ODR is the registers for setting or resetting bits
    // ODR = 0x0000000 means all the bits are resetted.
    GPIOA->ODR = 0x00000000;
    return CmdReturnBadParameter1;
  
  //
  } else {
    
    //If everything is fine just display the selected pin to the terminal
    printf("Selected Pin: %ld\n",led);
  }
  
  // To select the correspound pin to high or low
  // Register right of the value 1 with the amount of index
  shiftNumber = 1 << led;

  // Get delay value 1000 = 1 second
  fetch_uint32_arg(&delay);
  
  
  // delayTemp is to determine the timer roll times
  // delayTemp1 is to determine the polling times
  delayTemp = delay / 6550;
    
  delayTemp1 = delay % 6550;
  
  
  // Make the timer counter 0 before start timing  
  TIM11->CNT = 0;
    
  //Make the correspounding pin to high  
  GPIOA->ODR = GPIOA->ODR | shiftNumber;

  // Wait until polling time exceed the timer value.
  while((delayTemp1 * 10)  >  TIM11->CNT  ) { 

  }
  
  // Make the timer counter 0 before start timing for timer roll  
  TIM11->CNT = 0;
  WDTFeed();
  interruptValue = 0;
 
  while ( interruptValue < delayTemp) {
     //WDTFeed necessary to feed watchdog timer.
     WDTFeed();
    
  }
  
  // Reset the correspounding pin
  GPIOA->ODR = GPIOA->ODR & ~shiftNumber;

  return CmdReturnOk;

}

//Control the terminal with Leda command Leda <index> <high/low>
ADD_CMD("tim",tim,"                <Pin Number> <Delay Time>")



// FUNCTION      : TIM1_TRG_COM_TIM11_IRQHandler
// DESCRIPTION   : IRQHandler for timer interrupt,
//		 Calls the periodElapsedCallback function
// PARAMETERS    : void 
// RETURNS       : void

void TIM1_TRG_COM_TIM11_IRQHandler (void){
   
   HAL_TIM_IRQHandler(&tim111);
   
}


// FUNCTION      : HAL_TIM_PeriodElapsedCallback
// DESCRIPTION   : Timer calls the function every roll
// PARAMETERS    : TIM_HandleTypeDef 
// RETURNS       : void

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim){

	
  if(htim ==  &tim111){
  
      interruptValue = interruptValue + 1 ;
      HAL_TIM_Base_Start_IT(&tim111);
      
  
  }

}




